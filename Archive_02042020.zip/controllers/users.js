const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const User = require('../models/user');

exports.createUser = (req, res, next) => {
    bcrypt.hash(req.body.password, 10)
        .then((hash) => {
            const user = new User({
                email: req.body.email,
                password: hash,
                isApproved: false
            });
        
            user.save()
                .then((newUser) => {
                    res.status(201).json({
                        newUser: newUser
                    });
                })
                .catch((error) => {
                    res.status(500).json({
                        error: 'Could not create user.'
                    });
                });
        });
};

exports.loginUser = (req, res, next) => {
    let loggedInUser;

    // Try to find a user account with a matching email address
    User.findOne({ email: req.body.email })
        .then((user) => {
            if (!user) {
                return res.status(401).json({
                    error: 'Could not find a matching user account.'
                });
            }

            loggedInUser = user;

            if (!user.isApproved) {
                return res.status(401).json({
                    error: 'User account has not yet been approved.'
                });
            }
            
            // Check if the password is correct
            return bcrypt.compare(req.body.password, user.password);
        })
        .then((result) => {
            if (!result) {
                return res.status(401).json({
                    error: 'Could not login. Please enter a valid password.'
                });
            }
        
            const token = jwt.sign(
                { email: loggedInUser.email, userId: loggedInUser._id }, 
                'warrior-center-bellflower',
                { expiresIn: '3h' });
            
            res.status(200).json({
                token: token,
                expiresIn: 10800,
                userId: loggedInUser._id
            });
        })
        .catch(err => {
            return res.status(401).json({
                error: 'Could not find a valid user account.'
            });
        });
};