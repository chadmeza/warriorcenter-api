const Sermon = require('../models/sermon');
const fs = require('fs');

exports.getSermons = (req, res, next) => {
    Sermon.find().sort({ date: 'desc' })
        .then((sermons) => {
            res.status(200).json({
                sermons: sermons
            });
        })
        .catch((error) => {
            res.status(500).json({
                error: 'Could not find any sermons.'
            });
        });
};

exports.getLimitedSermons = (req, res, next) => {
    const queryLimit = parseInt(req.params.number);
    
    Sermon.find().limit(queryLimit).sort({ date: 'desc' })
        .then((sermons) => {
            res.status(200).json({
                sermons: sermons
            });
        })
        .catch((error) => {
            res.status(500).json({
                error: 'Could not find any sermons.'
            });
        });
};

exports.getSermon = (req, res, next) => {
    Sermon.findById(req.params.id)
        .then((sermon) => {
            if (sermon) {
                res.status(200).json({
                    sermon: sermon
                });
            } else {
                res.status(404).json({ 
                    error: 'Invalid sermon ID.' 
                });
            }
        })
        .catch((error) => {
            res.status(500).json({
                error: 'Could not find this sermon.'
            });
        });
};

exports.createSermon = (req, res, next) => {
    const url = req.protocol + "://" + req.get("host");
    const sermon = new Sermon({
        title: req.body.title,
        scripture: req.body.scripture,
        speaker: req.body.speaker,
        date: req.body.date,
        mp3: url + "/mp3/" + req.file.filename
    });

    Sermon.find()
        .then((sermons) => {
            if (sermons.length < 9) {
                sermon.save()
                    .then((newSermon) => {
                        res.status(201).json({
                            sermon: newSermon,
                            id: newSermon._id
                        });
                    })
                    .catch((error) => {
                        res.status(500).json({
                            error: 'Could not create a new sermon.'
                        });
                    });
            } else {
                res.status(500).json({
                    error: 'You have reached your limit for sermons. Your account only allows 10 sermons at a time.'
                });
            }
        })
        .catch((error) => {
            res.status(500).json({
                error: 'Could not access sermons.'
            });
        });
};
  
exports.updateSermon = (req, res, next) => {
    const sermon = new Sermon({
        _id: req.body.id,
        title: req.body.title,
        scripture: req.body.scripture,
        speaker: req.body.speaker,
        date: req.body.date,
        mp3: req.body.mp3
    });

    Sermon.updateOne({ _id: req.params.id }, sermon)
        .then((result) => {
            if (result.n > 0) {
                res.status(200).json({ 
                    sermon: result 
                });
            } else {
                res.status(401).json({ 
                    error: 'User is not authorized to make this change.' 
                });
            }
        })
        .catch((error) => {
            res.status(500).json({
                error: 'Could not update this sermon.'
            });
        });
};
  
exports.deleteSermon = (req, res, next) => {
    Sermon.findOneAndDelete({ _id: req.params.id }, (error, sermon) => {
        if (error) {
            res.status(401).json({ 
                error: 'User is not authorized to make this change.' 
            });
        }

        const parsedMP3Path = sermon.mp3.split('/');
        const pathToDelete = parsedMP3Path[parsedMP3Path.length - 2] + '/' + parsedMP3Path[parsedMP3Path.length - 1];

        fs.unlink(pathToDelete, (error) => {
            if (error) {
                res.status(500).json({
                    error: 'Could not delete this sermon.'
                });
            }

            res.status(200).json({ 
                sermon: sermon
            });
        });
    });
};