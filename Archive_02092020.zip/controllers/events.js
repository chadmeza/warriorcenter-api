const Event = require('../models/event');

exports.getEvents = (req, res, next) => {
    Event.find().sort({ date: 'asc' })
        .then((events) => {
            res.status(200).json({
                events: events
            });
        })
        .catch((error) => {
            res.status(500).json({
                error: 'Could not find any events.'
            });
        });
};

exports.getLimitedEvents = (req, res, next) => {
    const queryLimit = parseInt(req.params.number);

    Event.find().where('date').gt(Date.now()).limit(queryLimit).sort({ date: 'asc' })
        .then((events) => {
            res.status(200).json({
                events: events
            });
        })
        .catch((error) => {
            res.status(500).json({
                error: 'Could not find any events.'
            });
        });
};

exports.getEvent = (req, res, next) => {
    Event.findById(req.params.id)
        .then((event) => {
            if (event) {
                res.status(200).json({
                    event: event
                });
            } else {
                res.status(404).json({ 
                    error: 'Invalid event ID.' 
                });
            }
        })
        .catch((error) => {
            res.status(500).json({
                error: 'Could not find this event.'
            });
        });
};

exports.createEvent = (req, res, next) => {
    const event = new Event({
        name: req.body.name,
        details: req.body.details,
        address: req.body.address,
        date: req.body.date,
        time: req.body.time
    });

    event.save()
        .then((newEvent) => {
            res.status(201).json({
                event: newEvent,
                id: newEvent._id
            });
        })
        .catch((error) => {
            res.status(500).json({
                error: 'Could not create a new event.'
            });
        });
};
  
exports.updateEvent = (req, res, next) => {
    const event = new Event({
        _id: req.body.id,
        name: req.body.name,
        details: req.body.details,
        address: req.body.address,
        date: req.body.date,
        time: req.body.time
    });

    Event.updateOne({ _id: req.params.id }, event)
        .then((result) => {
            if (result.n > 0) {
                res.status(200).json({ 
                    event: result 
                });
            } else {
                res.status(401).json({ 
                    error: 'User is not authorized to make this change.' 
                });
            }
        })
        .catch((error) => {
            res.status(500).json({
                error: 'Could not update this event.'
            });
        });
};
  
exports.deleteEvent = (req, res, next) => {
    Event.deleteOne({ _id: req.params.id })
        .then((result) => {
            if (result.n > 0) {
                res.status(200).json({ 
                    result: result
                });
            } else {
                res.status(401).json({ 
                    error: 'User is not authorized to make this change.' 
                });
            }
        })
        .catch((error) => {
            res.status(500).json({
                error: 'Could not delete this event.'
            });
        });
};

exports.deleteOldEvents = (req, res, next) => {
    Event.deleteMany({ date: { $lte: Date.now() } }, (error, result) => {
        if (error) {
            res.status(500).json({
                error: 'Could not delete events.'
            });
        }

        res.status(200).json({ 
            result: result
        });
    });
};